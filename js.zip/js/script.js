/*Typeahead Book search*/
var url = '/';
    /*Book List*/
    $('#book_name.typeahead').typeahead({
            highlight: true
        },
        {
            name: 'books',
            source: function(query, syncResults, asyncResults) {
                $.get(url + 'bible/get_books/' + query, function(data) {
                    asyncResults(JSON.parse(data));
                });
            }
        });

    /*Chapter of Selected Book*/
    $('#bk_search').on('click', function(ev){
        var bk_name = $('#book_name').val();
        var ch_id = $('#chapter_id').val();
        var cj_mask = $('#cj_mask').val();
        if(!bk_name || !ch_id || cj_mask){
            ev.preventDefault();
        }
    });
    /*Book search end*/

/*Tooltip Begin*/
$("#prev").on('mousemove', function(e) {
    var mytop= e.pageY - 270;
    var myleft= e.pageX - 110;
    $("#prev-tooltip").css({top: mytop, left: myleft });
    $('#prev-tooltip[data-toggle="tooltip"]').tooltip('show')
});
$("#next").on('mousemove', function(e) {
    var mytop= e.pageY -270;
    var myleft= e.pageX - 110;
    $("#next-tooltip").css({top: mytop, left: myleft });
    $('#next-tooltip[data-toggle="tooltip"]').tooltip('show')
});
$("#prev, #next").on('mouseleave', function(e) {
    $('[data-toggle="tooltip"]').tooltip('hide')
});
/*Tooltip end*/

$('.nav_ch_season').on('click', function(){
    $('div.ch_season_bks').empty();
});
$('.nav_ch_ss7').on('click', function(){
    $('.ch_ss7_bks').empty();
});
function chapter_season(val){
   $.get(
        url+'chapter_study/show_ch_season_bks/'+val,
        function(response){
            $('.ch_season_bks').html(response);
        }
    )
}
function chapter_ss7(val){
    $.get(
        url+'chapter_study/show_ch_ss7_bks/'+val,
        function(response){
            $('.ch_ss7_bks').html(response);
        }
    )
}

/*var csn ='<?php echo $this->security->get_csrf_token_name();?>';
var csh = '<?php echo $this->security->get_csrf_hash();?>';*/